package com.example.adsetupdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdView;

public class InterstitialAdView extends AppCompatActivity {

    private InterstitialAd interstitialAd;
    private int click = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interstitial_ad_view);
        setTitle("Interstitial Ads");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        AudienceNetworkAds.initialize(this);

        interstitialAd = new InterstitialAd(this, "YOUR_PLACEMENT_ID");
        InterstitialAdListener listener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                Log.d("TAG", "displayed");
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.d("TAG", "dismissed");

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.d("TAG", "Error: " + adError.getErrorMessage());

            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.d("TAG", "adLoaded");
                interstitialAd.show();

            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.d("TAG", "adClicked");
                click++;
                if (click <= 3) {
                    return;
                }
                interstitialAd.isAdLoaded();
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.d("TAG", "loggingImpression");

            }
        };
        interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(listener).build());

        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(view -> {
            startActivity(new Intent(InterstitialAdView.this, NativeAds.class));
        });
    }
}