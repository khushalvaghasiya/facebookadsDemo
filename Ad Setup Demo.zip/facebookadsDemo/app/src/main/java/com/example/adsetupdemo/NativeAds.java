package com.example.adsetupdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;

import java.lang.annotation.Native;
import java.util.ArrayList;
import java.util.List;

public class NativeAds extends AppCompatActivity {

    private NativeAd nativeAd;
    private NativeAdLayout nativeAdLayout;
    private LinearLayout adView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_ads);
        setTitle("Native Ads");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AudienceNetworkAds.initialize(this);

        showNativeAds();

        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(view -> {
            startActivity(new Intent(NativeAds.this, NativeBannerAds.class));
        });
    }

    private void showNativeAds() {

        nativeAd = new NativeAd(this, "YOUR_PLACEMENT_ID");
        NativeAdListener listener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
                Log.d("TAG", "mediaDownloaded");
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.d("TAG", "onError");
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.d("TAG", "adLoaded");
                if (nativeAd == null || nativeAd != ad) {
                    return;
                }
                inflatAd();
            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.d("TAG", "adClicked");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.d("TAG", "loggingImpression");
            }
        };
        nativeAd.loadAd(nativeAd
                .buildLoadAdConfig()
                .withAdListener(listener)
                .build());

    }

    private void inflatAd() {

        nativeAd.unregisterView();

        nativeAdLayout = findViewById(R.id.native_ad_container);
        LayoutInflater inflater = LayoutInflater.from(NativeAds.this);
        adView = (LinearLayout) inflater.inflate(R.layout.custom_native_ad, nativeAdLayout, false);
        nativeAdLayout.addView(adView);

        LinearLayout adChoiceOptions = findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(NativeAds.this, nativeAd, nativeAdLayout);
        adChoiceOptions.addView(adOptionsView,0);

        MediaView nativeIcon = findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = findViewById(R.id.native_ad_title);
        MediaView nativeAdMedia = findViewById(R.id.native_ad_media);
        TextView sponsoredLabel = findViewById(R.id.native_ad_sponsored_label);
        TextView nativeAdSocialContext = findViewById(R.id.native_ad_social_context);
        TextView nativeAdBody = findViewById(R.id.native_ad_body);
        Button nativeAdCallToAction = findViewById(R.id.native_ad_call_to_action);

        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());

        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(adView, nativeAdMedia,clickableViews);

    }
}