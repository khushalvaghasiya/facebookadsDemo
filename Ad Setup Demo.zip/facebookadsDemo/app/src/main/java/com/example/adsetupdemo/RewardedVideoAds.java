package com.example.adsetupdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.RewardData;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.RewardedVideoAdListener;
public class RewardedVideoAds extends AppCompatActivity {

    private RewardedVideoAd rewardedVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewarded_video_ad);
        setTitle("Rewarded Video Ads");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        AudienceNetworkAds.initialize(this);

        rewardedVideoAd = new RewardedVideoAd(this, "YOUR_PLACEMENT_ID");
        RewardedVideoAdListener listener = new RewardedVideoAdListener() {
            @Override
            public void onRewardedVideoCompleted() {
                Log.d("TAG", "videoCompleted");
            }

            @Override
            public void onRewardedVideoClosed() {
                Log.d("TAG", "videoClosed");

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.d("TAG", "Error: " + adError.getErrorMessage());

            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.d("TAG", "adLoaded");
                rewardedVideoAd.show();

            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.d("TAG", "adClicked");

            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.d("TAG", "loggingImpression");

            }
        };
        RewardData rewardData = new RewardData("YOUR_USER_ID", "YOUR_REWARD");
        rewardedVideoAd.loadAd(rewardedVideoAd
                .buildLoadAdConfig()
                .withAdListener(listener)
                .withRewardData(rewardData)
                .build());

        Button btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(view -> {
            startActivity(new Intent(RewardedVideoAds.this, RewardedInterstitialAds.class));
        });
    }
}