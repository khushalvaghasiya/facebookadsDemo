package com.example.adsetupdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.RewardedInterstitialAd;
import com.facebook.ads.RewardedInterstitialAdListener;

public class RewardedInterstitialAds extends AppCompatActivity {

    private RewardedInterstitialAd rewardedInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewareded_interstitial_ads);
        setTitle("Rewarded Interstitial Ads");
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        AudienceNetworkAds.initialize(this);

        rewardedInterstitialAd = new RewardedInterstitialAd(this, "YOUR_PLACEMENT_ID");
        RewardedInterstitialAdListener listener = new RewardedInterstitialAdListener() {
            @Override
            public void onRewardedInterstitialCompleted() {
                Log.d("TAG", "Rewarded interstitial Completed");
            }

            @Override
            public void onRewardedInterstitialClosed() {
                Log.d("TAG", "Rewarded Interstitial Closed");

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.d("TAG", "Error: " + adError.getErrorMessage());

            }

            @Override
            public void onAdLoaded(Ad ad) {
                Log.d("TAG", "AddLoaded");
                rewardedInterstitialAd.show(rewardedInterstitialAd
                        .buildShowAdConfig()
                        .withAppOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                        .build());

            }

            @Override
            public void onAdClicked(Ad ad) {
                Log.d("TAG", "adClicked");

            }

            @Override
            public void onLoggingImpression(Ad ad) {
                Log.d("TAG", "loggingImpression");

            }
        };
        rewardedInterstitialAd.loadAd(rewardedInterstitialAd
                .buildLoadAdConfig()
                .withAdListener(listener)
                .build());
    }

    @Override
    protected void onDestroy() {
        if (rewardedInterstitialAd != null) {
            rewardedInterstitialAd.destroy();
            rewardedInterstitialAd = null;
        }
        super.onDestroy();
    }
}